Local walkthrough of the catalogue UI.

screenshots/ holds one full-page image per step.
video/walkthrough.webm plays the same steps in order:
home, near search for break bad, rating guide and TV-MA filter,
poster row with descriptions, See more, mood chips, taste results,
explore, about, and the API docs.
